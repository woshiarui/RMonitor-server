// This file is created by egg-ts-helper@1.34.7
// Do not modify this file!!!!!!!!!
/* eslint-disable */

import 'egg';
import ExportDataManage = require('../../../app/controller/dataManage');
import ExportHome = require('../../../app/controller/home');
import ExportReportDataController = require('../../../app/controller/reportDataController');

declare module 'egg' {
  interface IController {
    dataManage: ExportDataManage;
    home: ExportHome;
    reportDataController: ExportReportDataController;
  }
}
